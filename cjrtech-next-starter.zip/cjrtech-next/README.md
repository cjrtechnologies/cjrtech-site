# CJR Technologies — Next.js Starter

A production-ready Next.js site for **cjrtech.com**

## Quick start

```bash
npm install
npm run dev
```
Then visit http://localhost:3000

## Deploy to Vercel

1. Push this folder to a new GitHub repo (e.g. `cjrtech-site`)
2. Go to https://vercel.com → New Project → Import your repo
3. Accept defaults. After deploy, add your custom domain **cjrtech.com** in Project → Settings → Domains.
4. Copy the DNS record Vercel shows you and add it in Namecheap → Domain List → Manage → Advanced DNS.

## Brand Colors
- Navy: `#051120`
- Orange: `#FF6A3D`
- Ivory: `#FDF8F1`
- Beige: `#F8ECD9`

Icons via `lucide-react`. Tailwind theme in `tailwind.config.js`.