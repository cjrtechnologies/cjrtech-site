import Head from "next/head";
import { ArrowRight, ShieldCheck, Cloud, Code2, Server, Router, PhoneCall, Mail, Calendar, CheckCircle2, CreditCard, FileSignature } from "lucide-react";
import FeatureCard from "@/components/FeatureCard";
import ServiceCard from "@/components/ServiceCard";
import PriceCard from "@/components/PriceCard";

export default function Home() {
  const colors = { navy: "#051120", orange: "#FF6A3D", beige: "#F8ECD9", ivory: "#FDF8F1" };
  return (
    <div className="min-h-screen" style={{ background: colors.navy, color: colors.ivory }}>
      <Head>
        <title>CJR Technologies — Cloud. JavaScript. Routing.</title>
        <meta name="description" content="Modern websites, custom apps & secure networks — built fast. CJR Technologies integrates Stripe, Cal.com, DocuSign, and Stripe Identity." />
        <meta property="og:title" content="CJR Technologies" />
        <meta property="og:description" content="Modern websites, custom apps & secure networks — built fast." />
        <meta property="og:url" content="https://cjrtech.com" />
      </Head>
      <header className="mx-auto max-w-7xl px-6 py-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 grid place-items-center rounded-xl" style={{ background: colors.orange }}>
            <svg viewBox="0 0 64 64" className="h-7 w-7" fill="none">
              <path d="M32 6 54 18v28L32 58 10 46V18L32 6Z" stroke={colors.navy} strokeWidth="3" />
              <path d="M22 38V26m10 12V20m10 18V30" stroke={colors.navy} strokeWidth="3" strokeLinecap="round" />
              <circle cx="22" cy="24" r="3" fill={colors.navy} />
              <circle cx="32" cy="18" r="3" fill={colors.navy} />
              <circle cx="42" cy="28" r="3" fill={colors.navy} />
            </svg>
          </div>
          <div className="leading-tight">
            <div className="text-xl font-bold tracking-tight">CJR Technologies</div>
            <div className="text-xs opacity-80">Cloud. JavaScript. Routing.</div>
          </div>
        </div>
        <nav className="hidden md:flex items-center gap-6 text-sm opacity-90">
          <a href="#services" className="hover:opacity-100">Services</a>
          <a href="#process" className="hover:opacity-100">Process</a>
          <a href="#pricing" className="hover:opacity-100">Pricing</a>
          <a href="mailto:info@cjrtech.com" className="hover:opacity-100">Contact</a>
        </nav>
        <a href="mailto:info@cjrtech.com" className="inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium shadow" style={{ background: colors.orange, color: colors.ivory }}>
          Get a Quote <ArrowRight size={16} />
        </a>
      </header>
      <section className="mx-auto max-w-7xl px-6 pt-8 pb-20 grid lg:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">Modern websites, custom apps & secure networks — built fast.</h1>
          <p className="mt-4 text-base md:text-lg opacity-90" style={{ color: colors.beige }}>We help small businesses launch and automate with Stripe payments, scheduling, contracts, ID verification, and rock‑solid infrastructure.</p>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <a href="mailto:info@cjrtech.com" className="rounded-2xl px-5 py-3 font-semibold shadow" style={{ background: colors.orange, color: colors.ivory }}>Start a project</a>
            <a href="#pricing" className="rounded-2xl px-5 py-3 font-semibold border" style={{ borderColor: colors.beige, color: colors.beige }}>See pricing</a>
          </div>
          <div className="mt-6 flex items-center gap-4 text-sm opacity-80">
            <div className="flex items-center gap-2"><ShieldCheck size={18} /> PCI-safe payments via Stripe</div>
            <div className="flex items-center gap-2"><Calendar size={18} /> Cal.com scheduling</div>
          </div>
        </div>
        <div className="rounded-3xl p-6 shadow-xl border" style={{ background: "rgba(255,255,255,0.02)", borderColor: "rgba(255,255,255,0.08)" }}>
          <div className="grid grid-cols-2 gap-4">
            <FeatureCard icon={<Cloud />} title="Cloud" desc="Vercel & Supabase deployments" />
            <FeatureCard icon={<Code2 />} title="JavaScript" desc="Next.js & React Native apps" />
            <FeatureCard icon={<Router />} title="Routing" desc="DNS, networking, security" />
            <FeatureCard icon={<CreditCard />} title="Payments" desc="Stripe Checkout & Invoicing" />
            <FeatureCard icon={<FileSignature />} title="Contracts" desc="DocuSign / Dropbox Sign" />
            <FeatureCard icon={<Calendar />} title="Scheduling" desc="Cal.com booking" />
          </div>
        </div>
      </section>
      <section id="services" className="mx-auto max-w-7xl px-6 py-16">
        <h2 className="text-3xl font-bold">Services</h2>
        <p className="mt-2 opacity-80" style={{ color: colors.beige }}>Pick a starting point — we’ll tailor it to your business.</p>
        <div className="mt-8 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <ServiceCard icon={<Code2 />} title="Websites & PWAs" bullets={["Fast Next.js sites","SEO + analytics","CMS optional"]} />
          <ServiceCard icon={<Server />} title="APIs & Backends" bullets={["Supabase/Postgres","Auth & roles","File storage"]} />
          <ServiceCard icon={<CreditCard />} title="Payments & Billing" bullets={["Stripe Checkout","Invoices & reminders","Apple/Google Pay"]} />
          <ServiceCard icon={<Calendar />} title="Scheduling & Bookings" bullets={["Cal.com embeds","Reminders","Team routing"]} />
          <ServiceCard icon={<FileSignature />} title="Contracts & ID" bullets={["DocuSign embeds","Stripe Identity","Audit trails"]} />
          <ServiceCard icon={<Router />} title="Networking & DNS" bullets={["Domain & SSL","Email (Google)","On‑site setup"]} />
        </div>
      </section>
      <section id="process" className="mx-auto max-w-7xl px-6 py-16 border-t" style={{ borderColor: "rgba(255,255,255,0.08)" }}>
        <h2 className="text-3xl font-bold">How we work</h2>
        <div className="mt-8 grid md:grid-cols-4 gap-6">
          {[
            { step: "1", title: "Plan", desc: "Define goals, services, and integrations."},
            { step: "2", title: "Build", desc: "Design + develop the core experience."},
            { step: "3", title: "Integrate", desc: "Stripe, Cal.com, ID & contracts wired up."},
            { step: "4", title: "Launch", desc: "Deploy, monitor, and iterate with you."},
          ].map((s) => (
            <div key={s.step} className="rounded-2xl p-5 border" style={{ borderColor: "rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.02)" }}>
              <div className="text-sm opacity-70">Step {s.step}</div>
              <div className="mt-1 font-semibold">{s.title}</div>
              <div className="mt-2 text-sm opacity-80" style={{ color: "#F8ECD9" }}>{s.desc}</div>
            </div>
          ))}
        </div>
      </section>
      <section id="pricing" className="mx-auto max-w-7xl px-6 py-16">
        <h2 className="text-3xl font-bold">Starter packages</h2>
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <PriceCard name="Launch Site" price="$1,000" cta="Get Started" features={["5-page responsive site","Custom domain & SSL","Contact form / basic SEO"]} highlight />
          <PriceCard name="Pro Platform" price="$1,600–$1,800" cta="Build My Platform" features={["Vehicle booking module","Stripe + Cal.com + DocuSign","CMS optional + hosting setup"]} />
          <PriceCard name="Mobile Add‑On" price="from $2,000" cta="Add Mobile" features={["iOS or Android MVP","Payments & scheduling","Push notifications"]} />
        </div>
        <p className="mt-4 text-sm opacity-80" style={{ color: colors.beige }}>Transparent pricing. No monthly fees beyond vendor costs (Stripe, Cal.com, DocuSign, hosting).</p>
      </section>
      <section id="contact" className="mx-auto max-w-5xl px-6 py-16">
        <div className="rounded-3xl p-8 grid lg:grid-cols-2 gap-10 border" style={{ borderColor: "rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.02)" }}>
          <div>
            <h3 className="text-2xl font-bold">Tell us about your project</h3>
            <p className="mt-2 text-sm opacity-80" style={{ color: colors.beige }}>We’ll reply within one business day with next steps and a quick estimate.</p>
            <div className="mt-6 space-y-3 text-sm">
              <div className="flex items-center gap-2 opacity-90"><PhoneCall size={18} /> (555) 555‑5555</div>
              <div className="flex items-center gap-2 opacity-90"><Mail size={18} /> info@cjrtech.com</div>
            </div>
          </div>
          <form className="grid gap-4" action="mailto:info@cjrtech.com" method="post" encType="text/plain">
            <input required placeholder="Your name" className="rounded-xl px-4 py-3 bg-transparent border" style={{ borderColor: "rgba(255,255,255,0.2)" }} />
            <input type="email" required placeholder="Email" className="rounded-xl px-4 py-3 bg-transparent border" style={{ borderColor: "rgba(255,255,255,0.2)" }} />
            <input placeholder="Company (optional)" className="rounded-xl px-4 py-3 bg-transparent border" style={{ borderColor: "rgba(255,255,255,0.2)" }} />
            <textarea rows={4} placeholder="What do you want to build?" className="rounded-xl px-4 py-3 bg-transparent border" style={{ borderColor: "rgba(255,255,255,0.2)" }} />
            <button type="submit" className="rounded-2xl px-5 py-3 font-semibold shadow inline-flex items-center gap-2 justify-center bg-orange text-ivory">
              Send message <ArrowRight size={16} />
            </button>
            <p className="text-xs opacity-70" style={{ color: colors.beige }}>By submitting, you agree we can email you back about your project.</p>
          </form>
        </div>
      </section>
      <footer className="border-t" style={{ borderColor: "rgba(255,255,255,0.08)" }}>
        <div className="mx-auto max-w-7xl px-6 py-10 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-sm opacity-80">© {new Date().getFullYear()} CJR Technologies. All rights reserved.</div>
          <div className="flex items-center gap-4 text-sm opacity-80">
            <span className="flex items-center gap-1"><CheckCircle2 size={16} /> PCI-safe via Stripe</span>
            <span className="flex items-center gap-1"><CheckCircle2 size={16} /> DocuSign-ready</span>
            <span className="flex items-center gap-1"><CheckCircle2 size={16} /> Cal.com scheduling</span>
          </div>
        </div>
      </footer>
    </div>
  );
}