import { ArrowRight } from "lucide-react";
export default function PriceCard({ name, price, features, cta, highlight }: { name: string; price: string; features: string[]; cta: string; highlight?: boolean }) {
  return (
    <div className={`rounded-3xl p-6 border flex flex-col ${highlight ? "scale-[1.02]" : ""}`} style={{ borderColor: highlight ? "#FF6A3D" : "rgba(255,255,255,0.1)", background: highlight ? "rgba(255,106,61,0.08)" : "rgba(255,255,255,0.02)" }}>
      <div className="text-sm opacity-70">{name}</div>
      <div className="mt-1 text-3xl font-extrabold">{price}</div>
      <ul className="mt-4 space-y-2 text-sm opacity-90 list-disc ml-5">
        {features.map((f, i) => (<li key={i}>{f}</li>))}
      </ul>
      <a href="mailto:info@cjrtech.com" className="mt-6 inline-flex items-center justify-center gap-2 rounded-2xl px-4 py-3 font-semibold shadow bg-orange text-ivory">
        {cta} <ArrowRight size={16} />
      </a>
    </div>
  );
}