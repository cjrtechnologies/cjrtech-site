import { ReactNode } from "react";
export default function ServiceCard({ icon, title, bullets }: { icon: ReactNode; title: string; bullets: string[] }) {
  return (
    <div className="rounded-2xl p-6 border flex flex-col" style={{ borderColor: "rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.02)" }}>
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 grid place-items-center rounded-xl bg-orange text-navy">{icon}</div>
        <div className="text-lg font-semibold">{title}</div>
      </div>
      <ul className="mt-4 space-y-2 text-sm opacity-90 list-disc ml-5">
        {bullets.map((b, i) => (<li key={i}>{b}</li>))}
      </ul>
    </div>
  );
}