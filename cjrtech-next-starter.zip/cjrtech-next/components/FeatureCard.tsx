import { ReactNode } from "react";
export default function FeatureCard({ icon, title, desc }: { icon: ReactNode; title: string; desc: string }) {
  return (
    <div className="rounded-2xl p-4 border" style={{ borderColor: "rgba(255,255,255,0.1)" }}>
      <div className="flex items-center gap-3">
        <div className="h-9 w-9 grid place-items-center rounded-lg" style={{ background: "rgba(255,255,255,0.08)" }}>{icon}</div>
        <div className="font-semibold">{title}</div>
      </div>
      <div className="mt-2 text-sm opacity-80">{desc}</div>
    </div>
  );
}