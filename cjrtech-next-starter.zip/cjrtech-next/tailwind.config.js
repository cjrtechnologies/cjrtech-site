/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./pages/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: "#051120",
        orange: "#FF6A3D",
        beige: "#F8ECD9",
        ivory: "#FDF8F1",
      },
      borderRadius: { '2xl': '1rem' }
    },
  },
  plugins: [],
};